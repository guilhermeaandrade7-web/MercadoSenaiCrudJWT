const db = require('../config/database');
const jwt = require('jsonwebtoken');

class UserController {

    async cadastrar(req, res) {
        try {
            const { nome, email, senha } = req.body;
            const [result] = await db.query(
                "INSERT INTO users (nome, email, senha) VALUES (?, ?, ?)",
                [nome, email, senha]
            );
            res.status(201).json({ id: result.insertId });
        } catch (error) {
            res.status(500).json({ erro: error.message });
        }
    }

    async login(req, res) {
        try {
            const { email, senha } = req.body;
            const [rows] = await db.query(
                "SELECT * FROM users WHERE email=? AND senha=?",
                [email, senha]
            );

            if (rows.length === 0) {
                return res.status(401).json({ erro: "Credenciais inválidas" });
            }

            const user = rows[0];
            const token = jwt.sign(
                { id: user.id },
                process.env.JWT_SECRET,
                { expiresIn: '1d' }
            );

            res.json({ token });
        } catch (error) {
            res.status(500).json({ erro: error.message });
        }
    }
}

module.exports = new UserController();