const connection = require('../config/database')

class ProductController {

    async listar(req, res) {
        const [rows] = await connection.query("SELECT * FROM products")
        res.json(rows)
    }

    async criar(req, res) {
        const { nome, preco, estoque } = req.body

        const [result] = await connection.query(
            "INSERT INTO products (nome, preco, estoque) VALUES (?, ?, ?)",
            [nome, preco, estoque]
        )

        res.status(201).json({ id: result.insertId })
    }

    async atualizar(req, res) {
        const id = req.params.id
        const { nome, preco, estoque } = req.body

        await connection.query(
            "UPDATE products SET nome=?, preco=?, estoque=? WHERE id=?",
            [nome, preco, estoque, id]
        )

        res.json({ mensagem: "Produto atualizado" })
    }

    async deletar(req, res) {
        const id = req.params.id

        await connection.query("DELETE FROM products WHERE id=?", [id])

        res.status(204).send()
    }
}

module.exports = new ProductController()