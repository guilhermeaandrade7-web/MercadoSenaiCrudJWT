const db = require('../config/database');

class OrderController {

    async criarPedido(req, res) {
        try {
            const { user_id } = req.body;

            const [result] = await db.query(
                "INSERT INTO orders (user_id) VALUES (?)",
                [user_id]
            );

            res.status(201).json({ order_id: result.insertId });
        } catch (error) {
            res.status(500).json({ erro: error.message });
        }
    }

    async adicionarItem(req, res) {
        try {
            const { order_id, product_id, quantidade } = req.body;


            const [produto] = await db.query(
                "SELECT * FROM products WHERE id=?",
                [product_id]
            );

            if (produto.length === 0) {
                return res.status(404).json({ erro: "Produto não encontrado" });
            }

            const preco = produto[0].preco;


            await db.query(
                `INSERT INTO order_items 
                (order_id, product_id, quantidade, preco_unitario) 
                VALUES (?, ?, ?, ?)`,
                [order_id, product_id, quantidade, preco]
            );

            res.json({ mensagem: "Item adicionado com sucesso!" });
        } catch (error) {
            res.status(500).json({ erro: error.message });
        }
    }

    async listarPedidos(req, res) {
        try {

            const [rows] = await db.query("SELECT * FROM orders");
            res.json(rows);
        } catch (error) {
            res.status(500).json({ erro: error.message });
        }
    }

    async atualizarStatus(req, res) {
        try {
            const id = req.params.id;
            const { status } = req.body;


            await db.query(
                "UPDATE orders SET status=? WHERE id=?",
                [status, id]
            );

            res.json({ mensagem: "Status atualizado com sucesso!" });
        } catch (error) {
            res.status(500).json({ erro: error.message });
        }
    }
}

module.exports = new OrderController();