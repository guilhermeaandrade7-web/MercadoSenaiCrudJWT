const express = require('express')
const router = express.Router()
const controller = require('../controllers/orderController')

router.post('/', controller.criarPedido)
router.post('/item', controller.adicionarItem)
router.get('/', controller.listarPedidos)
router.put('/:id/status', controller.atualizarStatus)

module.exports = router