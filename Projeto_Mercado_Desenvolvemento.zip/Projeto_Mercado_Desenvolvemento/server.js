require('dotenv').config()

const express = require('express')
const cors = require('cors')

const userRoutes = require('./src/routes/userRoutes')
const productRoutes = require('./src/routes/productRoutes')
const orderRoutes = require('./src/routes/orderRoutes')

const app = express()

app.use(cors())
app.use(express.json())

app.use('/users', userRoutes)
app.use('/products', productRoutes)
app.use('/orders', orderRoutes)

const PORT = process.env.PORT || 3000

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`)
})